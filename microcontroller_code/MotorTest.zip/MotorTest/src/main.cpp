#include <Arduino.h>
#include "encoder_driver.h"
#include "pwm_driver.h"

// Variables for speed calculation
unsigned long lastTime = 0;
long lastPulseCount = 0;
int pwmValue = 0;


void setup() {
  Serial.begin(115200);
  
  // Initialize the motor speed reader
  initMotorSpeedReader();
  
  pinMode(24, INPUT_PULLUP);  // Changed to GPIO 24 for Teensy
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.println("Brushless Motor ESC Speed Reader Initialized (Teensy  )");
  Serial.println("Connect ESC speed signal to GPIO 2");
  
  lastTime = millis();
  digitalWrite(LED_BUILTIN, HIGH); // Turn on built-in LED
}

//testing program
void loop() {
  // Calculate and display motor speed every 500ms
  unsigned long currentTime = millis();
  
  if (currentTime - lastTime >= 500) {
    long currentPulseCount = readMotorPulses(FRONT_LEFT_MOTOR);
    long pulseDiff = currentPulseCount - lastPulseCount;
    float timeInterval = (currentTime - lastTime) / 1000.0; // Convert to seconds
    
    // Calculate pulses per second (Hz)


    float pulsesPerSecond = pulseDiff / timeInterval;
    
    float rpm = (pulsesPerSecond * 60.0) / PULSES_PER_REVOLUTION;

    bool slowDown = !digitalRead(24);  // Changed to GPIO 24 for Teensy
    
    Serial.print("Total Pulses: ");
    Serial.print(currentPulseCount);
    Serial.print(" | Pulses/sec: ");
    Serial.print(pulsesPerSecond);
    Serial.print(" Hz | Estimated RPM: ");
    Serial.print(rpm);
    Serial.print(" | Total rotations: ");
    Serial.println(currentPulseCount / PULSES_PER_REVOLUTION);
    
    lastPulseCount = currentPulseCount;
    lastTime = currentTime;

    setMotorPWM(FRONT_LEFT_MOTOR, pwmValue);
    if(pwmValue < PWM_MAX_VALUE && !slowDown) {
      pwmValue+=3;
      Serial.print(" Speeding Up ");
    }
    else if(pwmValue > 0 && slowDown) {
      pwmValue-=3;
      Serial.print(" Slowing Down ");
    }
    Serial.println(" | PWM Value Set To: " + String(pwmValue));
  }
  
  // Your motor control code can go here
}